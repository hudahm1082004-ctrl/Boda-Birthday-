const screens=[...document.querySelectorAll(".screen")];
const $=id=>document.getElementById(id);
function showScreen(id){screens.forEach(s=>s.classList.remove("active"));$(id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"})}
$("enterBtn").addEventListener("click",()=>{if($("password").value.trim()==="2008"){ $("passwordMsg").textContent="صح... المفاجأة بدأت ❤️"; setTimeout(startCandle,650)}else $("passwordMsg").textContent="مممم لأ 😂 جرّب تاني!"});
$("password").addEventListener("keydown",e=>{if(e.key==="Enter")$("enterBtn").click()});
function startCandle(){showScreen("candleScreen");let n=1;$("count").textContent=n;$("countText").textContent="واحد... 🕯️";const t=setInterval(()=>{n++;if(n<=3){$("count").textContent=n;$("countText").textContent=n===2?"اتنين... 👀":"تلاتة... 🎂"}else{clearInterval(t);$("flame").style.opacity="0";$("count").textContent="✨";$("countText").textContent="اتنفخت! يلا المفاجأة ❤️";setTimeout(()=>showScreen("introScreen"),850)}},900)}
document.querySelectorAll(".nextBtn").forEach(b=>b.addEventListener("click",()=>showScreen(b.dataset.next)));
const song=$("song"),play=$("play"),seek=$("seek"),volume=$("volume");
function fmt(s){if(!Number.isFinite(s))return"0:00";return Math.floor(s/60)+":"+String(Math.floor(s%60)).padStart(2,"0")}
play.addEventListener("click",async()=>{if(song.paused){await song.play();play.textContent="⏸"}else{song.pause();play.textContent="▶"}});
song.addEventListener("loadedmetadata",()=>{$("duration").textContent=fmt(song.duration)});
song.addEventListener("timeupdate",()=>{$("currentTime").textContent=fmt(song.currentTime);if(song.duration)seek.value=song.currentTime/song.duration*100});
seek.addEventListener("input",()=>{if(song.duration)song.currentTime=seek.value/100*song.duration});
volume.addEventListener("input",()=>song.volume=volume.value);
$("mute").addEventListener("click",()=>{song.muted=!song.muted;$("mute").textContent=song.muted?"🔇":"🔊"});
$("prev").addEventListener("click",()=>song.currentTime=0);
$("next").addEventListener("click",()=>song.currentTime=Math.min(song.duration||0,song.currentTime+10));
song.addEventListener("ended",()=>play.textContent="▶");
